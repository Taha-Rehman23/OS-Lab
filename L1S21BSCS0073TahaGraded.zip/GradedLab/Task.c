#include<stdio.h>

struct Customer{

int ID;
char Fname[10];
char Lname[10]; 
char Address[20];
char City[10];

}ctr;

int main(int argc, char** argv)
{


FILE *filePtr ; 

//filePtr = fopen(“customer.txt”, “ab”);

printf("Enter Customer ID : ");
scanf("%d", &ctr.ID);

printf("Enter Customer First Name : ");
scanf("%s", ctr.Fname);

printf("Enter Customer Last Name : ");
scanf("%s", ctr.Lname);

printf("Enter Customer Address : ");
scanf("%s", ctr.Address);

printf("Enter Customer City : ");
scanf("%s", ctr.City);


fprintf(filePtr, "%d  %s  %s  %s  %s", ctr.ID, ctr.Fname, ctr.Lname, ctr.Address, ctr.City);


return 0;
}
