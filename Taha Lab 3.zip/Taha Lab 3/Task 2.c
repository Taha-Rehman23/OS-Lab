#include <stdio.h>

int main()
{
int side1=0,side2=0,side3=0;
printf("Enter 1st side of Triangle: ");
scanf("%d", &side1);

printf("Enter 2nd side of Triangle: ");
scanf("%d", &side2);

printf("Enter 3rd side of Triangle: ");
scanf("%d", &side3);

if (side1 > side2+side3 || side2 > side1+side3 || side3 > side2+side1)
{
printf("This is not a Triangle \n");
}else
{
   if (side1 == side3 && side1 == side3)
{
     printf("This is Equelent Triangle \n");
}else if (side1 == side2|| side1 == side3 || side2 == side3)
{
     printf("This is Isosceles Triangle \n");
}else if (side1 != side2 && side1 != side3 && side2 != side3)
{
   printf("This is Scalene Triangle \n");
}
}

return 0;
}
