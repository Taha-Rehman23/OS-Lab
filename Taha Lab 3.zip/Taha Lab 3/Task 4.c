#include <stdio.h>

void isPrime()
{
    int input=0,chking=1;
    printf("Enter a Number: ");
    scanf("%d", &input);

if (input<2)
{
     printf("Entered Number is not prime\n");
}else
{
      for (int i = 2; i < input/2; i++)
    {
        if (input%i==0)
        {
            chking=0;
            break;
        }
    }

     if (chking)
    {
         printf("Entered Number is prime\n");
    }
    else{
         printf("Entered Number is not prime\n");
    }
}
  
  
}

int main()
{

   isPrime();

   return 0;
}
