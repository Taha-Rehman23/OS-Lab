#include <stdio.h>

int main()
{

int size=0;
int numbers[20];

for (int i = 0; i < 20; i++)
{
    scanf("%d", &numbers[i]);
     if (numbers[i]== -99)
     {
        break;
     }
     else{
        size++;
     }
}

printf("Entered array was : ");
for (int x = 0; x < size; x++)
{
  printf("%d  ", numbers[x]);
}


int temp=0;
for (int i = 0;  i < size; i++)
{
    for (int x = 0; x < size - i -1; x++)
{
    if (numbers[x] > numbers[x+1])
    {
        temp = numbers[x];
        numbers[x] = numbers[x+1];
        numbers[x+1] = temp;
    }
}
}

printf("\nSorted array is : ");
for (int x = 0; x < size; x++)
{
  printf("%d  ", numbers[x]);
}

return 0;
}
