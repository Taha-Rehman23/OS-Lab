#include <stdio.h>

int main()
{
int length=0,width=0,result=0;
printf("Enter Length of Rectangle: ");
scanf("%d", &length);

printf("Enter Width of Rectangle: ");
scanf("%d", &width);

result=length*width;

printf("Area of Rectangle is: %d\n" , result);

return 0;
}
